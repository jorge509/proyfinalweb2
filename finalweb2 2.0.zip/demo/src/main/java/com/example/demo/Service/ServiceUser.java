package com.example.demo.Service;


import java.util.List;




import com.example.demo.Models.User;
public interface ServiceUser {
	List<User> findAll();
	User findById(Integer id);
	User save(User u);
	User deleteById(Integer id);
	List<User> findByNomeLike(String nome);
	User findByIdentificacao(long i);
}