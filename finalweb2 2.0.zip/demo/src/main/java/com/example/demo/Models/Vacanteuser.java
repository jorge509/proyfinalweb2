package com.example.demo.Models;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name="Vacanteuser")
public class Vacanteuser {

	
    @Id    
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
	private int vagaId;
    
    private int userId;
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getVagaId() {
		return vagaId;
	}

	public void setVagaId(int vagaId) {
		this.vagaId = vagaId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Vacanteuser() {
	}

	public Vacanteuser(int vagaId, int userId) {
		this.vagaId = vagaId;
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Vacanteuser [id=" + id + ", userId=" + userId + ", vagaId=" + vagaId + "]";
	}

	

	
    

}
