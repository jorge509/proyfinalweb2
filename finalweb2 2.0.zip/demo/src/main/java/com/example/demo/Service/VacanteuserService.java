package com.example.demo.Service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.Models.Vacanteuser;

@Service
public interface VacanteuserService {
	  List<Vacanteuser> findAll();
	  Vacanteuser findById(Integer id);
	  Vacanteuser save(Vacanteuser vu);
	  Vacanteuser deleteById(Integer id);
	  List<Vacanteuser> findByVagaId(Integer id);
}
