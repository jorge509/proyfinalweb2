package  com.example.demo.Repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Models.User;


@Repository
public interface RepositoryUser extends JpaRepository<User,Integer> {
	
	    List<User> findByNomeLike(String nome);
		User findByIdentificacao(long i);


}
