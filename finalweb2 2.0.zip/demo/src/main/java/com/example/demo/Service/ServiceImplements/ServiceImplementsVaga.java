package com.example.demo.Service.ServiceImplements;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Models.Vaga;
import com.example.demo.Repository.RepositoryVaga;
import com.example.demo.Service.ServiceVaga;




@Service
public class ServiceImplementsVaga   implements ServiceVaga{
    @Autowired
    RepositoryVaga repositoryvaga;

    @Override
	public List<Vaga> findAll() {
		// TODO Auto-generated method stub
		return repositoryvaga.findAll();
	}


	  @Override
	    public Vaga findById(Integer id) {
	        return repositoryvaga.findById(id).get();
	    }


	@Override
	public Vaga save(Vaga v) {
		// TODO Auto-generated method stub
		return repositoryvaga.save(v);
	}


	@Override
	public Vaga deleteById(Integer id) {
		// TODO Auto-generated method stub
		return deleteById(id);
	}


	@Override
	public List<Vaga> findByTipoLike(String tipo) {
		// TODO Auto-generated method stub
		return repositoryvaga.findByTipoLike(tipo);
	}


	



	 
	
}
