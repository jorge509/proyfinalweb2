package com.example.demo.Service.ServiceImplements;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Models.User;
import com.example.demo.Repository.RepositoryUser;
import com.example.demo.Service.ServiceUser;





@Service
public class ServiceImplementsUser  implements ServiceUser{
@Autowired
RepositoryUser userRepository;
	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User findById(Integer id) {
		// TODO Auto-generated method stub
		return findById(id);
	}

	@Override
	public User save(User u) {
		// TODO Auto-generated method stub
		return userRepository.save(u);
	}

	@Override
	public List<User> findByNomeLike(String nome) {
		// TODO Auto-generated method stub
		return userRepository.findByNomeLike(nome);
	}

	@Override
	public User deleteById(Integer id) {
		// TODO Auto-generated method stub
		return  deleteById(id);
	}

	@Override
	public User findByIdentificacao(long i) {
		// TODO Auto-generated method stub
		return userRepository.findByIdentificacao(i);
	}

	

	
	
	
}
