package com.example.demo.Controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.Models.User;
import com.example.demo.Models.Vacanteuser;
import com.example.demo.Models.Vaga;
import com.example.demo.Repository.RepositoryUser;
import com.example.demo.Repository.RepositoryVaga;
import com.example.demo.Repository.VacanteuserRepository;



@Controller
public class controller {
	 @Autowired              
	    RepositoryUser repositoryuser;
 @Autowired
	RepositoryVaga repovaga;
	
	 @Autowired 
	VacanteuserRepository vacanuserrepo;
	 
	 
	//inicial view
	 @RequestMapping(value = "/index", method = RequestMethod.GET)		//funcionando		
	 public ModelAndView getVacantes(){		
		  ModelAndView mv = new ModelAndView("index");
	        List<Vaga> vacantelist = repovaga.findAll(); 
	        List<User> userList = repositoryuser.findAll();
	        mv.addObject("vaga", vacantelist);
	        mv.addObject("usuario", userList);
	        return mv;
	    }
	    
	 //Cadastros
	    @RequestMapping(value = "/index/CadastrarUsuario",method = RequestMethod.GET)     	//funcionando
	    public String insertarUser(){
	        return "CadastrarUsuario";
	    }
	    
	    @RequestMapping(value="/index/CadastrarVaga",method = RequestMethod.GET)			//funcionando
	    public ModelAndView insertarVaga(){
	        ModelAndView mv = new ModelAndView("CadastrarVaga");
	        List<User> userList = repositoryuser.findAll();
	        mv.addObject("usuario",userList );
	        return mv;
	    }
	    
	    
	    @RequestMapping(value = "/index/CadastrarUsuario", method= RequestMethod.POST )      	//funcionando             
	    public String saveUsuario(@Valid User u, BindingResult result, RedirectAttributes attributes){
	        
	        try {
				if(u.getImg()==null){
					u.setImg("bla bla bla");
				}
				if(result.hasErrors()){
					System.out.println(u.toString());
					System.out.println(result.toString());
					attributes.addFlashAttribute("error","Verificar los campos obligatorios"+u.toString());
					return "redirect:/index/CadastrarUsuario";
				}
	           
	        	 
	        	u.setPass(new BCryptPasswordEncoder().encode(u.getPass()));
				System.out.println(u.toString());
				System.out.println(result.toString());
	            repositoryuser.save(u);
                attributes.addFlashAttribute("exito","Cadastro realizado com exito");
				return "redirect:/index";
            
        } catch (Exception e) {System.out.println(e.toString());}
        System.out.println(u.toString());
					System.out.println(result.toString());
        return "redirect:/index";
    }
	   
	    @RequestMapping(value = "/index/CadastrarVaga",method=RequestMethod.POST)		//funcionando
	    public String saveVaga(@Valid Vaga v, BindingResult result, RedirectAttributes attributes){
	    	if(v.getVisible()==null){ v.setVisible(false);
	           }else{ v.setVisible(true);}
	        if(result.hasErrors()){
	            attributes.addFlashAttribute("error","Verifique os campos obrigatórios:"+v.toString());
	            return "redirect:/index/CadastrarVaga";
	        }
	        User em = repositoryuser.findById(v.getIdEmpresa()).orElse(null);
	        
	        if(em!=null){
				v.setDate(LocalDate.now().toString());
	        	repovaga.save(v);
	            attributes.addFlashAttribute("exito","Vaga cadastrada");
	            return "redirect:/index";
	        }
	        else{
	            attributes.addFlashAttribute("error"," verifique as caixas marcadas | "+ v.toString()+" |"+em.toString());
	            return "redirect:/index/CadastrarVaga";
	        }      
	    }
	    
	    //listar
	    @RequestMapping(value = "/index/Usuario", method = RequestMethod.GET)		//funcionando
	    public ModelAndView getUsuario(){	
	        ModelAndView mv = new ModelAndView("Usuario");
	        List<User> userList = repositoryuser.findAll(); 
	        mv.addObject("usuario", userList);
	        return mv;
	    }

	    @RequestMapping(value = "/index/Usuario/delete/{id}", method= RequestMethod.GET )	//funcionando
	    public String deleteUser(@PathVariable("id") int id, RedirectAttributes attributes){
	       try{
	    	   repositoryuser.deleteById(id);
	        attributes.addFlashAttribute("exito","Usuario "+id+" deletado");
	        return "redirect:/index/Usuario";
	       }catch(Exception e){
	        attributes.addFlashAttribute("error","id inexistente ou erro desconhecido");
	        return "redirect:/index/Usuario";
	       } 
	    }
	   
	    @RequestMapping(value = "/index/Vaga/delete/{id}", method= RequestMethod.GET )	//funcionando
	    public String deleteVaga(@PathVariable("id") int id, RedirectAttributes attributes){
	       try{
	    	   repovaga.deleteById(id);
	        attributes.addFlashAttribute("exito","Vaga "+id+" deletada");
	        return "redirect:/index";
	       }catch(Exception e){
	        attributes.addFlashAttribute("error","id inexistente ou erro desconhecido");
	        return "redirect:/index";
	       } 
	    }
	    
	    //update
	   
	    @RequestMapping(value = "/index/Usuario/update/{id}", method= RequestMethod.GET )                   
	    public ModelAndView updateUsuario(@PathVariable("id") int id){                            
	        ModelAndView mv = new ModelAndView("updateUsuario");                        
	        User usu =  repositoryuser.findById(id).orElse(null);    
			mv.addObject("id",id);                           
	        mv.addObject("nome",usu.getNome());
			mv.addObject("sobrenome",usu.getSobrenome());
	        mv.addObject("telefone",usu.getTelefone());
	        mv.addObject("tipo",usu.getTipo());
			mv.addObject("identificacao",usu.getIdentificacao());
	        mv.addObject("dataNacimento",usu.getDataNacimento());
	       // mv.addObject("img",usu.get().getImg());
	        mv.addObject("usuario",usu.getUsuario());
	        mv.addObject("pass",usu.getPass());
	        return mv;
	    }
	    @RequestMapping(value = "/index/Vaga/update/{id}", method= RequestMethod.GET )                   
	    public ModelAndView updateVaga(@PathVariable("id") int id){                            
	        ModelAndView mv = new ModelAndView("updateVaga");                        
	        
			Vaga vag =  repovaga.findById(id).orElse(null);       
			
			List<User> userList = repositoryuser.findAll();     
			
			User use  = repositoryuser.findById(vag.getIdEmpresa()).orElse(null);  
			                 
	        mv.addObject("nome",vag.getNomeVaga());
	        mv.addObject("tipo",vag.getTipo());
	        mv.addObject("idEmpresa",vag.getIdEmpresa());
			mv.addObject("idNomeEmpresa",use.getNome());
	        mv.addObject("visible",vag.getVisible());
	        mv.addObject("descricao",vag.getDescricao());
			mv.addObject("usuario",userList);
	        return mv;
			
			
	    }

	    @RequestMapping(value = "/index/Usuario/update/{id}", method= RequestMethod.POST )                   //Verificação URL, valor = endereço e method = POST (GET,POST,etc.) enviar valores para o formulario
	    public String saveUpdateUsuario(@PathVariable("id") int id, User usuario, RedirectAttributes attributes){
	        try {
	            User postExistente = repositoryuser.findById(id).orElse(null);       
	            System.out.println(postExistente.toString());
				postExistente.setNome(usuario.getNome());
				postExistente.setSobrenome(usuario.getSobrenome());
	            postExistente.setTelefone(usuario.getTelefone());
	            postExistente.setTipo(usuario.getTipo());
				postExistente.setIdentificacao(usuario.getIdentificacao());
	            postExistente.setDataNacimento(usuario.getDataNacimento().toString());
	            postExistente.setUsuario(usuario.getUsuario());
	            postExistente.setPass(new BCryptPasswordEncoder().encode(usuario.getPass()));
	            repositoryuser.save(postExistente);
	            attributes.addFlashAttribute("exito","Post Editado com sucesso ");
	            return "redirect:/index/Usuario";
	               
	        } catch (Exception e) {
	            attributes.addFlashAttribute("error","Não foi possivel editar, confira os campos de texto"+e.toString());
	            return "redirect:/index/Usuario/update/{id}";
	        }
	    }
	    
	    @RequestMapping(value = "/index/Vaga/update/{id}", method= RequestMethod.POST )                 
	    public String saveUpdateVaga(@PathVariable("id") int id, Vaga vaga, RedirectAttributes attributes){
	        try {
	            Vaga postExistente = repovaga.findById(id).orElse(null);
	            postExistente.setNomeVaga(vaga.getNomeVaga());
	            postExistente.setTipo(vaga.getTipo());
	            postExistente.setDescricao(vaga.getDescricao());
	            postExistente.setVisible(vaga.getVisible());
				postExistente.setDate(LocalDate.now().toString());
				postExistente.setIdEmpresa(vaga.getIdEmpresa());
	            repovaga.save(postExistente);
	            attributes.addFlashAttribute("exito","Post Editado com sucesso ");
	            return "redirect:/index";
	            } catch (Exception e) {
	            attributes.addFlashAttribute("error","Não foi possivel editar, confira os campos de texto");
	            return "redirect:/index/Vaga/update/{id}";
	            }
	    }

	    @RequestMapping(value = "index/Vaga/{id}", method= RequestMethod.GET )                   //funcionando
	    public ModelAndView getVaga(@PathVariable("id") int id){                            
	        ModelAndView mv = new ModelAndView("vaga");                        
	        java.util.Optional<Vaga> vaga =  repovaga.findById(id); 
	        java.util.Optional<User> usu = repositoryuser.findById(vaga.get().getId());                              
	        mv.addObject("nome",vaga.get().getNomeVaga());
	        mv.addObject("tipo",vaga.get().getTipo());
	        mv.addObject("visible",vaga.get().getVisible());
	        mv.addObject("id",vaga.get().getId());
	        mv.addObject("img",usu.get().getImg());
	        mv.addObject("nomeUsu",usu.get().getNome());
	        mv.addObject("descricao",vaga.get().getDescricao());
	        return mv;
	    }
	    
	    
	  
	    @RequestMapping(value="index/Vaga/{id}",method=RequestMethod.POST)		//não ta funcionando 
	   public String getSaveInscreverVaga(@PathVariable("id") int id, @RequestParam Long identificacao, RedirectAttributes attributes){
	    try {
	        
	        User u = repositoryuser.findByIdentificacao(identificacao);
			if(u!=null){
				Vacanteuser vucu = new Vacanteuser(id,u.getId());
				vacanuserrepo.save(vucu);  
				attributes.addFlashAttribute("exito","Inscrito com sucesso ");
				return "redirect:/index";
			}else{
				attributes.addFlashAttribute("error","não foi possivel realizar a incrição, identificação não encontrada ");
				return "redirect:/index/Vaga/{id}";
			}
	        
	    } catch (Exception e) {
	        attributes.addFlashAttribute("error","Não foi possivel realizar a inscrição");
	        return "redirect:/index/Vaga/{id}";
	    }
	   }

	   @RequestMapping(value = "/index/Vaga/{id}/usuario", method = RequestMethod.GET)	//funcionando
	   public ModelAndView getInscritosPorVaga(@PathVariable("id") int id){
	       ModelAndView mv = new ModelAndView("usuario");
		   List<Vacanteuser> listvacante = vacanuserrepo.findByVagaId( id);
	       System.out.println(listvacante.toString());
		 List<User> userList = new ArrayList<>();  
		   for(Vacanteuser vu:listvacante){
				userList.add(repositoryuser.findById(vu.getUserId()).orElse(null));
		   }
	       
	       System.out.println(userList.toString());
	       mv.addObject("usuario", userList);
	       return mv;
	   }
	
	   }

    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
	















