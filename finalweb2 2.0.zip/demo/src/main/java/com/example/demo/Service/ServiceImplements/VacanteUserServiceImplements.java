package com.example.demo.Service.ServiceImplements;

import java.util.List;


import com.example.demo.Models.Vacanteuser;
import com.example.demo.Repository.VacanteuserRepository;
import com.example.demo.Service.VacanteuserService;

public class VacanteUserServiceImplements implements VacanteuserService {

	VacanteuserRepository vacanteuserrepository;

	@Override
	public List<Vacanteuser> findAll() {
		// TODO Auto-generated method stub
		return vacanteuserrepository.findAll();
	}

	@Override
	public Vacanteuser findById(Integer id) {
		// TODO Auto-generated method stub
		return vacanteuserrepository.findById(id).get();
	}

	@Override
	public Vacanteuser save(Vacanteuser vu) {
		// TODO Auto-generated method stub
		return vacanteuserrepository.save(vu);
	}

	@Override
	public Vacanteuser deleteById(Integer id) {
		// TODO Auto-generated method stub
		return deleteById(id);
	}

	@Override
	public List<Vacanteuser> findByVagaId(Integer id) {
		// TODO Auto-generated method stub
		return vacanteuserrepository.findByVagaId(id);
	}

	

	
}