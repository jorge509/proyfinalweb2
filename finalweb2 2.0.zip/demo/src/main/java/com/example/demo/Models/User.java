package com.example.demo.Models;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.Id;
@Entity
@Table(name="User")
public class User {
  
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @NotBlank
    private String nome;
    @NotBlank
    private String tipo;
    private String sobrenome;
    private String usuario;
    private String pass;
    private String img;
    private long identificacao;
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd-MM-yyyy")
    private LocalDate dataNacimento;
    private String telefone;
    
    
    public long getIdentificacao() {
        return identificacao;
    }
    public void setIdentificacao(long identificacao) {
        this.identificacao = identificacao;
    }
    public String getTelefone() {
	return telefone;
}
public void setTelefone(String telefone) {
	this.telefone = telefone;
}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	
    
    
    
    
    public User(@NotBlank String nome, @NotBlank String tipo, String sobrenome, String usuario, String pass, String img,
            long identificacao, LocalDate dataNacimento, String telefone) {
        this.nome = nome;
        this.tipo = tipo;
        this.sobrenome = sobrenome;
        this.usuario = usuario;
        this.pass = pass;
        this.img = img;
        this.identificacao = identificacao;
        this.dataNacimento = dataNacimento;
        this.telefone = telefone;
    }
    
    @Override
    public String toString() {
        return "User [dataNacimento=" + dataNacimento + ", id=" + id + ", identificacao=" + identificacao + ", img="
                + img + ", nome=" + nome + ", pass=" + pass + ", sobrenome=" + sobrenome + ", telefone=" + telefone
                + ", tipo=" + tipo + ", usuario=" + usuario + "]";
    }
    public User() {
    }
   
    public int getId() {
        return id;
    }
    public void setId(int id) {
        id = this.id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getSobrenome() {
        return sobrenome;
    }
    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }
   
  
    public LocalDate getDataNacimento() {
        return dataNacimento;
    }
    public void setDataNacimento(String dataNacimento) {
        this.dataNacimento = LocalDate.parse(dataNacimento);
    }
   


}
