package com.example.demo.Service;

import java.util.List;


import com.example.demo.Models.Vaga;
public interface ServiceVaga {
	 List<Vaga> findAll();
	    Vaga findById(Integer id);
	    Vaga save(Vaga v);
	    List<Vaga> findByTipoLike(String tipo);
	    Vaga deleteById(Integer id);
}
